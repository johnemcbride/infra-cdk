Seed bundle
